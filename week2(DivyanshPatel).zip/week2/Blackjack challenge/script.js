$(document).ready(function () {
    let gameInProgress = false;
    let userHand = [], dealerHand = [];
    let userScore, dealerScore;
    
    const deck = [2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K', 'A'];
  
    $("#start-button").click(function () {
      if (!gameInProgress) {
        gameInProgress = true;
        userHand = [];
        dealerHand = [];
        $("#content").empty();
        displayMessage("Do you want to play a game of Blackjack? Type 'y' or 'n': ", true);
      }
    });
  
    function startGame() {
      userHand.push(drawCard(), drawCard());
      dealerHand.push(drawCard(), drawCard());
      displayHands();
      promptForAction();
    }
  
    function drawCard() {
      return deck[Math.floor(Math.random() * deck.length)];
    }
  
    function calculateScore(hand) {
      let score = 0;
      let aceCount = 0;
  
      hand.forEach(card => {
        if (card === 'A') {
          score += 11;
          aceCount++;
        } else if (['J', 'Q', 'K'].includes(card)) {
          score += 10;
        } else {
          score += card;
        }
      });
  
      while (score > 21 && aceCount) {
        score -= 10;
        aceCount--;
      }
  
      return score;
    }
  
    function displayHands() {
      userScore = calculateScore(userHand);
      dealerScore = calculateScore(dealerHand);
  
      displayMessage(`Your cards: [${userHand.join(', ')}], score: ${userScore}`);
      displayMessage(`Dealer's first card: [${dealerHand[0]}]`);
    }
  
    function promptForAction() {
      if (userScore > 21) {
        displayMessage("You went over 21! You lose 😢", false);
        endGame();
      } else {
        displayMessage("Type 'y' to get another card, type 'n' to stand: ", true);
      }
    }
  
    function endGame() {
      dealerPlay();
      compareScores();
      displayMessage("Do you want to play again? Type 'y' or 'n': ", true);
    }
  
    function dealerPlay() {
      while (dealerScore < 17) {
        dealerHand.push(drawCard());
        dealerScore = calculateScore(dealerHand);
      }
  
      displayMessage(`Dealer's cards: [${dealerHand.join(', ')}], score: ${dealerScore}`);
    }
  
    function compareScores() {
      if (userScore > 21) {
        displayMessage("You lose 😤", false);
      } else if (dealerScore > 21 || userScore > dealerScore) {
        displayMessage("You win 😁", false);
      } else if (userScore === dealerScore) {
        displayMessage("It's a tie! 🙃", false);
      } else {
        displayMessage("You lose 😞", false);
      }
    }
  
    function displayMessage(message, isInputPrompt = false) {
      $("#content").append(`<div>${message}</div>`);
      if (isInputPrompt) {
        const inputField = $('<input type="text" class="terminal-input" autocomplete="off" />');
        $("#content").append(inputField);
        inputField.focus();
      }
    }
  
    $(document).on('keydown', function (e) {
      if (gameInProgress && e.key === 'Enter') {
        const input = $(".terminal-input").val().toLowerCase();
        $(".terminal-input").prop("disabled", true);
        
        if (input === 'y') {
          if (!userHand.length) {
            startGame();
          } else {
            userHand.push(drawCard());
            displayHands();
            promptForAction();
          }
        } else if (input === 'n') {
          if (userHand.length) {
            endGame();
          } else {
            gameInProgress = false;
            displayMessage("Thanks for playing! Goodbye!", false);
          }
        }
      }
    });
  });
  