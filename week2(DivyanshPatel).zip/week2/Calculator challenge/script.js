// Constants
const inputPrompts = [
  `+
-
*
/
Pick an operation: `,
  "What's the next number?: ",
];
const operations = ["+", "-", "*", "/"];
let currentInputId = undefined;
let inputValues = [];
let accumulator = 0;
let currentOperation;
let secondNumber = 0;

// Initialize the application
$(document).ready(function () {
  $("#run-button").click(function () {
    $("#Content").empty();
    restart();
  });

  // Handle input when Enter key is pressed
  $(document).on("keydown", function (e) {
    const key = e.which || e.keyCode;
    if (key === 13) {
      handleUserInput();
    }
  });

  // Adjust input box size based on user input length
  $(document).on("keydown", function (e) {
    const inputLine = $("#" + currentInputId + " input");
    const inputLength = inputLine.val().length;
    inputLine.attr("size", inputLength ? inputLength * 0.95 : 1);
  });

  // Focus input box when clicked
  $(document).on("click", function () {
    $("#" + currentInputId + " input").focus();
  });
});

// Restart the calculator
function restart() {
  inputValues = [];
  accumulator = 0;
  secondNumber = 0;
  currentOperation = undefined;
  newLine("Welcome to the Interactive Calculator. Type the first number:", true);
}

// Handle user input
function handleUserInput() {
  const userInput = $("#" + currentInputId + " input").val();
  inputValues.push({ id: currentInputId, value: userInput });

  if (inputValues.length === 1) {
    accumulator = Number(userInput);
    $(".console-carrot").remove();
    newLine(inputPrompts[0], true);
  } else if (inputValues.length === 2 || (inputValues.length > 4 && (inputValues.length + 1) % 3 === 0)) {
    currentOperation = operations.indexOf(userInput.trim());
    $(".console-carrot").remove();
    newLine(inputPrompts[1], true);
  } else if (inputValues.length === 3 || (inputValues.length > 4 && inputValues.length % 3 === 0)) {
    secondNumber = Number(userInput);
    $(".console-carrot").remove();
    computeResult();
  } else if (inputValues.length === 4 || (inputValues.length > 4 && (inputValues.length - 1) % 3 === 0)) {
    if (userInput.toLowerCase() === "y") {
      newLine(inputPrompts[0], true);
    } else {
      $("#Content").empty();
      restart();
    }
  }
}

// Compute the result based on the operation
function computeResult() {
  let result = 0;
  switch (currentOperation) {
    case 0: result = accumulator + secondNumber; break;
    case 1: result = accumulator - secondNumber; break;
    case 2: result = accumulator * secondNumber; break;
    case 3: result = accumulator / secondNumber; break;
    default: break;
  }

  newLine(
    `${formatNumber(accumulator)} ${operations[currentOperation]} ${formatNumber(secondNumber)} = ${formatNumber(result)}`,
    false
  );

  accumulator = result;
  newLine(
    `Type 'y' to continue calculating with ${formatNumber(accumulator)}, or type 'n' to start a new calculation: `,
    true
  );
}

// Format numbers to show decimal points if necessary
function formatNumber(num) {
  return num % 1 === 0 ? `${num}.0` : num;
}

// Create a new line in the terminal
function newLine(text, isPrompt) {
  $(".console-carrot").remove();

  if (currentInputId !== undefined) {
    $("#" + currentInputId + " input").prop("disabled", true);
  }

  currentInputId = "consoleInput-" + generateId();

  if (isPrompt) {
    $("#Content").append(
      `<div id="${currentInputId}">${text}<input autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" type="text" class="terminal-input" /><div class="console-carrot"></div></div>`
    );
    $("#" + currentInputId + " input").focus();
    $("#" + currentInputId + " input").attr("size", "1");
  } else {
    $("#Content").append(`<div id="${currentInputId}">${text}</div>`);
  }

  document.getElementById(currentInputId).scrollIntoView();
}

// Generate a unique ID
function generateId() {
  return Math.random().toString(16).slice(2);
}
