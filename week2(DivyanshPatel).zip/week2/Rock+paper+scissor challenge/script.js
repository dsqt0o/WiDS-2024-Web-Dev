const choices = [
  `Rock\n    _______\n---'   ____)\n      (_____)\n      (_____)\n      (____)\n---.__(___)\n`,
  `Paper\n    _______\n---'   ____)____\n          ______)\n          _______)\n         _______)\n---.__________)\n`,
  `Scissors\n    _______\n---'   ____)____\n          ______)\n       __________)\n      (____)\n---.__(___)\n`,
];

const results = {
  win: "You win!",
  lose: "You lose!",
  draw: "It's a draw!",
};

let gameOutput;

function startGame() {
  gameOutput = document.getElementById("game-output");
  gameOutput.textContent = "Game started! Enter your choice.";
}

function playGame(userChoice) {
  const computerChoice = Math.floor(Math.random() * 3);

  gameOutput.textContent = `You chose:\n${choices[userChoice]}\nComputer chose:\n${choices[computerChoice]}`;

  if (userChoice === computerChoice) {
    gameOutput.textContent += `\n${results.draw}`;
  } else if (
    (userChoice === 0 && computerChoice === 2) ||
    (userChoice === 1 && computerChoice === 0) ||
    (userChoice === 2 && computerChoice === 1)
  ) {
    gameOutput.textContent += `\n${results.win}`;
  } else {
    gameOutput.textContent += `\n${results.lose}`;
  }
}

document.getElementById("start-button").addEventListener("click", startGame);

document.getElementById("submit-button").addEventListener("click", () => {
  const userChoice = parseInt(document.getElementById("choice-input").value, 10);

  if (isNaN(userChoice) || userChoice < 0 || userChoice > 2) {
    gameOutput.textContent = "Invalid input. Please enter 0, 1, or 2.";
  } else {
    playGame(userChoice);
  }
});
